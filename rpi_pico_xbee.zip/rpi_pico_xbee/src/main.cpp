/*
 * Copyright (c) 2023 Libre Solar Technologies GmbH
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include <stdio.h>
#include <zephyr/kernel.h>
#include <zephyr/devicetree.h>
#include <zephyr/device.h>
#include <zephyr/drivers/gpio.h>
#include "drivers/xbee/xbee.hpp"

#define XBEE_UART_NODE DT_CHOSEN(cansat_xbee)

int main(void)
{
	const struct device *xbee_node_dev = DEVICE_DT_GET(XBEE_UART_NODE);
	drivers::xbee::Xbee xbee(xbee_node_dev);

    drivers::xbee::detail::request::transmit_request tx_req;
    tx_req.set_dst_address(0x0013A20041CFED46);
    tx_req.set_frame_id(0);

	//LED
	static const struct gpio_dt_spec led_dev = GPIO_DT_SPEC_GET(DT_NODELABEL(led), gpios);
    gpio_pin_configure_dt(&led_dev, GPIO_OUTPUT_ACTIVE);
	int i = 1;
    while(1){
		//LED-------------------------------------------------------------
        printk("nel main\n");
        k_msleep(500);
        gpio_pin_toggle_dt(&led_dev);

        //XBEE-------------------------------------------------------------
        tx_req.set_payload("welaaaaaaaa");
        i++;
        tx_req.calculate_length();
        tx_req.calculate_checksum();
        xbee.send_request(tx_req);
        
		k_sleep(K_MSEC(100));
    }
	return 0;
}


